sleep 2
CLASSPATH=/system/framework/u2.jar app_process / com.test.uirun.Main >> /data/local/tmp/u2.log 2>&1 &