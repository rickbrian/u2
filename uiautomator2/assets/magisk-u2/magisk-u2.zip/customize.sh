print_modname() {
  ui_print " "
  ui_print "    ********************************************"
  ui_print "    *          Magisk/KernelSU/APatch          *"
  ui_print "    *           magisk uiautomator2            *"
  ui_print "    ********************************************"
  ui_print " "
}

ui_print "magisk uiautomator2 Successfully installed"